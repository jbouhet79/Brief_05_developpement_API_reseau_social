﻿CREATE SEQUENCE fakenames_seq;
CREATE TABLE fakenames (
  number int NOT NULL PRIMARY KEY DEFAULT nextval('fakenames_seq'),
  surname varchar(23) NOT NULL,
  givenname varchar(20) NOT NULL,
  age int NOT NULL,
  password varchar(25) NOT NULL,
  emailaddress varchar(100) NOT NULL,
  telephonenumber varchar(25) NOT NULL,
  username varchar(25) NOT NULL
);

insert into fakenames values(nextval('fakenames_seq'),'Lacroix','Matthieu',25,'Ailu2aes5ah','MatthieuLacroix@teleworm.us','02.68.38.35.04','Coulart1999');
insert into fakenames values(nextval('fakenames_seq'),'Arpin','Brice',34,'shohR2iTae','BriceArpin@gustr.com','01.06.48.38.73','Crent1989');
insert into fakenames values(nextval('fakenames_seq'),'Lafrenière','Pierpont',55,'Boo3Usaey','PierpontLafreniere@cuvox.de','03.92.08.36.25','Warchat');
insert into fakenames values(nextval('fakenames_seq'),'Champagne','Xarles',63,'Gie8amoaph','XarlesChampagne@armyspy.com','05.86.72.02.89','Fouslond');
insert into fakenames values(nextval('fakenames_seq'),'Coupart','Daisi',72,'HephuiN9qu','DaisiCoupart@dayrep.com','05.78.40.17.03','Movenciought');
insert into fakenames values(nextval('fakenames_seq'),'L''Hiver','Marine',23,'MiaPhic2','MarineLHiver@superrito.com','01.81.21.52.27','Whicily');
insert into fakenames values(nextval('fakenames_seq'),'Douffet','Virginie',24,'eoWo8iel','VirginieDouffet@superrito.com','01.21.09.73.92','Knotood');
insert into fakenames values(nextval('fakenames_seq'),'Louis','Brier',71,'Bahzoth2ah','BrierLouis@fleckens.hu','03.90.09.98.81','Haday1953');
insert into fakenames values(nextval('fakenames_seq'),'Pitre','Alfred',73,'Lie2eeloJ6ee','AlfredPitre@gustr.com','04.33.53.87.27','Fould1950');
insert into fakenames values(nextval('fakenames_seq'),'Lécuyer','Édouard',22,'Ohphainoo3','EdouardLecuyer@rhyta.com','01.59.14.73.29','Sarronever');
